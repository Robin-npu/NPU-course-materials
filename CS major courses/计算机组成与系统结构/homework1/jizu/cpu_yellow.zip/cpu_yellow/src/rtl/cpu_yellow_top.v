`timescale 1ns/1ps

// CPU_YELLOW: a compact five-stage pipelined MIPS-I compatible core.
// Top-level interface is intentionally kept identical to CPUYellow_task.md.
// Notes:
// 1. The external memory model should return instr/dmem_rdata one cycle after the
//    corresponding address/read request is issued.
// 2. The top-level interface has no byte-enable port. For SB/SH, dmem_wdata is
//    shifted to the addressed byte lane; the provided cocotb memory model peeks
//    internal ex_mem_mem_size and ex_mem_addr[1:0] to apply byte/halfword stores.

module cpu_yellow_top(
    input             clk,
    input             rst_n,
    input      [31:0] instr,
    output     [31:0] instr_addr,
    output     [31:0] dmem_addr,
    output     [31:0] dmem_wdata,
    input      [31:0] dmem_rdata,
    output            dmem_we,
    output            dmem_re
);

    localparam [31:0] RESET_PC = 32'hBFC0_0000;
    localparam [31:0] EXC_VEC  = 32'hBFC0_0380;

    localparam [5:0] OP_SPECIAL = 6'b000000;
    localparam [5:0] OP_REGIMM  = 6'b000001;
    localparam [5:0] OP_J       = 6'b000010;
    localparam [5:0] OP_JAL     = 6'b000011;
    localparam [5:0] OP_BEQ     = 6'b000100;
    localparam [5:0] OP_BNE     = 6'b000101;
    localparam [5:0] OP_BLEZ    = 6'b000110;
    localparam [5:0] OP_BGTZ    = 6'b000111;
    localparam [5:0] OP_ADDI    = 6'b001000;
    localparam [5:0] OP_ADDIU   = 6'b001001;
    localparam [5:0] OP_SLTI    = 6'b001010;
    localparam [5:0] OP_SLTIU   = 6'b001011;
    localparam [5:0] OP_ANDI    = 6'b001100;
    localparam [5:0] OP_ORI     = 6'b001101;
    localparam [5:0] OP_XORI    = 6'b001110;
    localparam [5:0] OP_LUI     = 6'b001111;
    localparam [5:0] OP_COP0    = 6'b010000;
    localparam [5:0] OP_LB      = 6'b100000;
    localparam [5:0] OP_LH      = 6'b100001;
    localparam [5:0] OP_LW      = 6'b100011;
    localparam [5:0] OP_LBU     = 6'b100100;
    localparam [5:0] OP_LHU     = 6'b100101;
    localparam [5:0] OP_SB      = 6'b101000;
    localparam [5:0] OP_SH      = 6'b101001;
    localparam [5:0] OP_SW      = 6'b101011;

    localparam [5:0] FN_SLL     = 6'h00;
    localparam [5:0] FN_SRL     = 6'h02;
    localparam [5:0] FN_SRA     = 6'h03;
    localparam [5:0] FN_SLLV    = 6'h04;
    localparam [5:0] FN_SRLV    = 6'h06;
    localparam [5:0] FN_SRAV    = 6'h07;
    localparam [5:0] FN_JR      = 6'h08;
    localparam [5:0] FN_JALR    = 6'h09;
    localparam [5:0] FN_SYSCALL = 6'h0c;
    localparam [5:0] FN_BREAK   = 6'h0d;
    localparam [5:0] FN_MFHI    = 6'h10;
    localparam [5:0] FN_MTHI    = 6'h11;
    localparam [5:0] FN_MFLO    = 6'h12;
    localparam [5:0] FN_MTLO    = 6'h13;
    localparam [5:0] FN_MULT    = 6'h18;
    localparam [5:0] FN_MULTU   = 6'h19;
    localparam [5:0] FN_DIV     = 6'h1a;
    localparam [5:0] FN_DIVU    = 6'h1b;
    localparam [5:0] FN_ADD     = 6'h20;
    localparam [5:0] FN_ADDU    = 6'h21;
    localparam [5:0] FN_SUB     = 6'h22;
    localparam [5:0] FN_SUBU    = 6'h23;
    localparam [5:0] FN_AND     = 6'h24;
    localparam [5:0] FN_OR      = 6'h25;
    localparam [5:0] FN_XOR     = 6'h26;
    localparam [5:0] FN_NOR     = 6'h27;
    localparam [5:0] FN_SLT     = 6'h2a;
    localparam [5:0] FN_SLTU    = 6'h2b;

    localparam [4:0] ALU_ADD  = 5'd0;
    localparam [4:0] ALU_SUB  = 5'd1;
    localparam [4:0] ALU_AND  = 5'd2;
    localparam [4:0] ALU_OR   = 5'd3;
    localparam [4:0] ALU_XOR  = 5'd4;
    localparam [4:0] ALU_NOR  = 5'd5;
    localparam [4:0] ALU_SLT  = 5'd6;
    localparam [4:0] ALU_SLTU = 5'd7;
    localparam [4:0] ALU_SLL  = 5'd8;
    localparam [4:0] ALU_SRL  = 5'd9;
    localparam [4:0] ALU_SRA  = 5'd10;
    localparam [4:0] ALU_LUI  = 5'd11;
    localparam [4:0] ALU_PASS = 5'd12;
    localparam [4:0] ALU_MULT = 5'd13;
    localparam [4:0] ALU_MULTU= 5'd14;
    localparam [4:0] ALU_DIV  = 5'd15;
    localparam [4:0] ALU_DIVU = 5'd16;

    localparam [2:0] WB_ALU = 3'd0;
    localparam [2:0] WB_MEM = 3'd1;
    localparam [2:0] WB_PC8 = 3'd2;
    localparam [2:0] WB_HILO= 3'd3;
    localparam [2:0] WB_CP0 = 3'd4;

    localparam [1:0] MS_BYTE = 2'd0;
    localparam [1:0] MS_HALF = 2'd1;
    localparam [1:0] MS_WORD = 2'd2;

    localparam [4:0] EXC_INT = 5'd0;
    localparam [4:0] EXC_ADEL= 5'd4;
    localparam [4:0] EXC_ADES= 5'd5;
    localparam [4:0] EXC_SYS = 5'd8;
    localparam [4:0] EXC_BP  = 5'd9;
    localparam [4:0] EXC_RI  = 5'd10;
    localparam [4:0] EXC_OV  = 5'd12;

    // ---------------------------------------------------------------------
    // PC / IF stage. instr is one-cycle delayed relative to instr_addr.
    // ---------------------------------------------------------------------
    reg [31:0] pc;
    reg [31:0] if_pc_d;
    assign instr_addr = pc;

    // IF/ID pipeline register.
    reg        if_id_valid;
    reg [31:0] if_id_pc;
    reg [31:0] if_id_instr;

    // Register file wires.
    wire [4:0] dec_rs = if_id_instr[25:21];
    wire [4:0] dec_rt = if_id_instr[20:16];
    wire [4:0] dec_rd = if_id_instr[15:11];
    wire [4:0] dec_sa = if_id_instr[10:6];
    wire [5:0] dec_op = if_id_instr[31:26];
    wire [5:0] dec_fn = if_id_instr[5:0];
    wire [15:0] dec_imm16 = if_id_instr[15:0];
    wire [25:0] dec_index = if_id_instr[25:0];

    wire [31:0] rf_rs_data;
    wire [31:0] rf_rt_data;
    reg         wb_reg_write;
    reg  [4:0]  wb_dest;
    reg  [31:0] wb_data;

    cpu_yellow_regfile u_regfile(
        .clk(clk),
        .rst_n(rst_n),
        .we(wb_reg_write),
        .waddr(wb_dest),
        .wdata(wb_data),
        .raddr1(dec_rs),
        .raddr2(dec_rt),
        .rdata1(rf_rs_data),
        .rdata2(rf_rt_data)
    );

    // CP0 registers.
    reg [31:0] cp0_badvaddr /* verilator public_flat_rw */;
    reg [31:0] cp0_count /* verilator public_flat_rw */;
    reg [31:0] cp0_status /* verilator public_flat_rw */;
    reg [31:0] cp0_cause /* verilator public_flat_rw */;
    reg [31:0] cp0_epc /* verilator public_flat_rw */;
    reg        cp0_count_tick;

    // HI/LO registers.
    reg [31:0] hi_reg /* verilator public_flat_rw */;
    reg [31:0] lo_reg /* verilator public_flat_rw */;

    // ---------------------------------------------------------------------
    // Decode stage control signals.
    // ---------------------------------------------------------------------
    reg        d_reg_write;
    reg        d_mem_read;
    reg        d_mem_write;
    reg [1:0]  d_mem_size;
    reg        d_mem_unsigned;
    reg        d_alu_src_imm;
    reg        d_imm_zeroext;
    reg [4:0]  d_alu_op;
    reg [2:0]  d_wb_sel;
    reg [4:0]  d_dest;
    reg        d_uses_rs;
    reg        d_uses_rt;
    reg        d_is_branch;
    reg        d_is_jump;
    reg        d_is_jr;
    reg        d_is_link;
    reg        d_is_eret;
    reg        d_reserved;
    reg        d_syscall;
    reg        d_break;
    reg        d_overflow_check;
    reg        d_shift_imm;
    reg        d_hi_we;
    reg        d_lo_we;
    reg        d_hilo_read_hi;
    reg        d_hilo_read_lo;
    reg        d_cp0_read;
    reg        d_cp0_write;
    reg [4:0]  d_cp0_rd;
    reg [2:0]  d_cp0_sel;

    reg        d_bcond_taken;
    reg [31:0] d_branch_target;

    wire [31:0] dec_imm_sign = {{16{dec_imm16[15]}}, dec_imm16};
    wire [31:0] dec_imm_zero = {16'b0, dec_imm16};
    wire [31:0] dec_imm_ext  = d_imm_zeroext ? dec_imm_zero : dec_imm_sign;

    // Read-after-write forwarding into branch/JR compare in ID stage.
    reg [31:0] id_rs_val;
    reg [31:0] id_rt_val;
    reg [31:0] ex_mem_forward_value;

    // Forward from MEM/WB. wb_data is computed combinational from MEM/WB below.
    always @(*) begin
        id_rs_val = rf_rs_data;
        id_rt_val = rf_rt_data;
        if (ex_mem_valid && ex_mem_reg_write && !ex_mem_mem_read && ex_mem_dest != 5'd0 && ex_mem_dest == dec_rs)
            id_rs_val = ex_mem_forward_value;
        else if (mem_wb_valid && mem_wb_reg_write && mem_wb_dest != 5'd0 && mem_wb_dest == dec_rs)
            id_rs_val = wb_data;

        if (ex_mem_valid && ex_mem_reg_write && !ex_mem_mem_read && ex_mem_dest != 5'd0 && ex_mem_dest == dec_rt)
            id_rt_val = ex_mem_forward_value;
        else if (mem_wb_valid && mem_wb_reg_write && mem_wb_dest != 5'd0 && mem_wb_dest == dec_rt)
            id_rt_val = wb_data;
    end

    // Main decoder.
    always @(*) begin
        d_reg_write      = 1'b0;
        d_mem_read       = 1'b0;
        d_mem_write      = 1'b0;
        d_mem_size       = MS_WORD;
        d_mem_unsigned   = 1'b0;
        d_alu_src_imm    = 1'b0;
        d_imm_zeroext    = 1'b0;
        d_alu_op         = ALU_ADD;
        d_wb_sel         = WB_ALU;
        d_dest           = 5'd0;
        d_uses_rs        = 1'b0;
        d_uses_rt        = 1'b0;
        d_is_branch      = 1'b0;
        d_is_jump        = 1'b0;
        d_is_jr          = 1'b0;
        d_is_link        = 1'b0;
        d_is_eret        = 1'b0;
        d_reserved       = 1'b0;
        d_syscall        = 1'b0;
        d_break          = 1'b0;
        d_overflow_check = 1'b0;
        d_shift_imm      = 1'b0;
        d_hi_we          = 1'b0;
        d_lo_we          = 1'b0;
        d_hilo_read_hi   = 1'b0;
        d_hilo_read_lo   = 1'b0;
        d_cp0_read       = 1'b0;
        d_cp0_write      = 1'b0;
        d_cp0_rd         = dec_rd;
        d_cp0_sel        = if_id_instr[2:0];
        d_bcond_taken    = 1'b0;
        d_branch_target  = if_id_pc + 32'd4;

        if (!if_id_valid) begin
            // Bubble.
        end else begin
            case (dec_op)
                OP_SPECIAL: begin
                    case (dec_fn)
                        FN_SLL: begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rt=1'b1; d_shift_imm=1'b1; d_alu_op=ALU_SLL; end
                        FN_SRL: begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rt=1'b1; d_shift_imm=1'b1; d_alu_op=ALU_SRL; end
                        FN_SRA: begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rt=1'b1; d_shift_imm=1'b1; d_alu_op=ALU_SRA; end
                        FN_SLLV:begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_op=ALU_SLL; end
                        FN_SRLV:begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_op=ALU_SRL; end
                        FN_SRAV:begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_op=ALU_SRA; end
                        FN_JR: begin d_uses_rs=1'b1; d_is_jump=1'b1; d_is_jr=1'b1; d_branch_target=id_rs_val; end
                        FN_JALR: begin d_uses_rs=1'b1; d_is_jump=1'b1; d_is_jr=1'b1; d_is_link=1'b1; d_reg_write=1'b1; d_dest=(dec_rd==5'd0)?5'd31:dec_rd; d_wb_sel=WB_PC8; d_branch_target=id_rs_val; end
                        FN_SYSCALL: begin d_syscall=1'b1; end
                        FN_BREAK: begin d_break=1'b1; end
                        FN_MFHI: begin d_reg_write=1'b1; d_dest=dec_rd; d_wb_sel=WB_HILO; d_hilo_read_hi=1'b1; end
                        FN_MFLO: begin d_reg_write=1'b1; d_dest=dec_rd; d_wb_sel=WB_HILO; d_hilo_read_lo=1'b1; end
                        FN_MTHI: begin d_uses_rs=1'b1; d_hi_we=1'b1; end
                        FN_MTLO: begin d_uses_rs=1'b1; d_lo_we=1'b1; end
                        FN_MULT: begin d_uses_rs=1'b1; d_uses_rt=1'b1; d_hi_we=1'b1; d_lo_we=1'b1; d_alu_op=ALU_MULT; end
                        FN_MULTU:begin d_uses_rs=1'b1; d_uses_rt=1'b1; d_hi_we=1'b1; d_lo_we=1'b1; d_alu_op=ALU_MULTU; end
                        FN_DIV: begin d_uses_rs=1'b1; d_uses_rt=1'b1; d_hi_we=1'b1; d_lo_we=1'b1; d_alu_op=ALU_DIV; end
                        FN_DIVU:begin d_uses_rs=1'b1; d_uses_rt=1'b1; d_hi_we=1'b1; d_lo_we=1'b1; d_alu_op=ALU_DIVU; end
                        FN_ADD: begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_op=ALU_ADD; d_overflow_check=1'b1; end
                        FN_ADDU:begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_op=ALU_ADD; end
                        FN_SUB: begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_op=ALU_SUB; d_overflow_check=1'b1; end
                        FN_SUBU:begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_op=ALU_SUB; end
                        FN_AND: begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_op=ALU_AND; end
                        FN_OR:  begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_op=ALU_OR; end
                        FN_XOR: begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_op=ALU_XOR; end
                        FN_NOR: begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_op=ALU_NOR; end
                        FN_SLT: begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_op=ALU_SLT; end
                        FN_SLTU:begin d_reg_write=1'b1; d_dest=dec_rd; d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_op=ALU_SLTU; end
                        default: begin d_reserved=1'b1; end
                    endcase
                end
                OP_REGIMM: begin
                    d_uses_rs = 1'b1;
                    d_is_branch = 1'b1;
                    d_branch_target = if_id_pc + 32'd4 + {{14{dec_imm16[15]}}, dec_imm16, 2'b00};
                    case (dec_rt)
                        5'b00000: d_bcond_taken = id_rs_val[31];               // BLTZ
                        5'b00001: d_bcond_taken = !id_rs_val[31];              // BGEZ
                        5'b10000: begin d_bcond_taken = id_rs_val[31]; d_is_link=1'b1; d_reg_write=1'b1; d_dest=5'd31; d_wb_sel=WB_PC8; end // BLTZAL
                        5'b10001: begin d_bcond_taken = !id_rs_val[31]; d_is_link=1'b1; d_reg_write=1'b1; d_dest=5'd31; d_wb_sel=WB_PC8; end // BGEZAL
                        default: begin d_reserved=1'b1; d_is_branch=1'b0; end
                    endcase
                end
                OP_J: begin
                    d_is_jump = 1'b1;
                    d_branch_target = {if_id_pc[31:28], dec_index, 2'b00};
                end
                OP_JAL: begin
                    d_is_jump=1'b1; d_is_link=1'b1; d_reg_write=1'b1; d_dest=5'd31; d_wb_sel=WB_PC8;
                    d_branch_target = {if_id_pc[31:28], dec_index, 2'b00};
                end
                OP_BEQ: begin d_uses_rs=1'b1; d_uses_rt=1'b1; d_is_branch=1'b1; d_bcond_taken=(id_rs_val==id_rt_val); d_branch_target=if_id_pc+32'd4+{{14{dec_imm16[15]}},dec_imm16,2'b00}; end
                OP_BNE: begin d_uses_rs=1'b1; d_uses_rt=1'b1; d_is_branch=1'b1; d_bcond_taken=(id_rs_val!=id_rt_val); d_branch_target=if_id_pc+32'd4+{{14{dec_imm16[15]}},dec_imm16,2'b00}; end
                OP_BLEZ:begin d_uses_rs=1'b1; d_is_branch=1'b1; d_bcond_taken=(id_rs_val[31] || id_rs_val==32'd0); d_branch_target=if_id_pc+32'd4+{{14{dec_imm16[15]}},dec_imm16,2'b00}; end
                OP_BGTZ:begin d_uses_rs=1'b1; d_is_branch=1'b1; d_bcond_taken=(!id_rs_val[31] && id_rs_val!=32'd0); d_branch_target=if_id_pc+32'd4+{{14{dec_imm16[15]}},dec_imm16,2'b00}; end
                OP_ADDI: begin d_reg_write=1'b1; d_dest=dec_rt; d_uses_rs=1'b1; d_alu_src_imm=1'b1; d_alu_op=ALU_ADD; d_overflow_check=1'b1; end
                OP_ADDIU:begin d_reg_write=1'b1; d_dest=dec_rt; d_uses_rs=1'b1; d_alu_src_imm=1'b1; d_alu_op=ALU_ADD; end
                OP_SLTI: begin d_reg_write=1'b1; d_dest=dec_rt; d_uses_rs=1'b1; d_alu_src_imm=1'b1; d_alu_op=ALU_SLT; end
                OP_SLTIU:begin d_reg_write=1'b1; d_dest=dec_rt; d_uses_rs=1'b1; d_alu_src_imm=1'b1; d_alu_op=ALU_SLTU; end
                OP_ANDI: begin d_reg_write=1'b1; d_dest=dec_rt; d_uses_rs=1'b1; d_alu_src_imm=1'b1; d_imm_zeroext=1'b1; d_alu_op=ALU_AND; end
                OP_ORI:  begin d_reg_write=1'b1; d_dest=dec_rt; d_uses_rs=1'b1; d_alu_src_imm=1'b1; d_imm_zeroext=1'b1; d_alu_op=ALU_OR; end
                OP_XORI: begin d_reg_write=1'b1; d_dest=dec_rt; d_uses_rs=1'b1; d_alu_src_imm=1'b1; d_imm_zeroext=1'b1; d_alu_op=ALU_XOR; end
                OP_LUI:  begin d_reg_write=1'b1; d_dest=dec_rt; d_alu_src_imm=1'b1; d_imm_zeroext=1'b1; d_alu_op=ALU_LUI; end
                OP_COP0: begin
                    if (if_id_instr == 32'h42000018) begin
                        d_is_eret = 1'b1;
                    end else if (if_id_instr[25:21] == 5'b00000) begin // MFC0
                        d_cp0_read=1'b1; d_reg_write=1'b1; d_dest=dec_rt; d_wb_sel=WB_CP0;
                        if (!((dec_rd==5'd8 || dec_rd==5'd9 || dec_rd==5'd12 || dec_rd==5'd13 || dec_rd==5'd14) && d_cp0_sel==3'd0)) d_reserved=1'b1;
                    end else if (if_id_instr[25:21] == 5'b00100) begin // MTC0
                        d_cp0_write=1'b1; d_uses_rt=1'b1;
                        if (!((dec_rd==5'd8 || dec_rd==5'd9 || dec_rd==5'd12 || dec_rd==5'd13 || dec_rd==5'd14) && d_cp0_sel==3'd0)) d_reserved=1'b1;
                    end else begin
                        d_reserved=1'b1;
                    end
                end
                OP_LB:  begin d_reg_write=1'b1; d_dest=dec_rt; d_uses_rs=1'b1; d_alu_src_imm=1'b1; d_mem_read=1'b1; d_mem_size=MS_BYTE; d_mem_unsigned=1'b0; d_wb_sel=WB_MEM; end
                OP_LBU: begin d_reg_write=1'b1; d_dest=dec_rt; d_uses_rs=1'b1; d_alu_src_imm=1'b1; d_mem_read=1'b1; d_mem_size=MS_BYTE; d_mem_unsigned=1'b1; d_wb_sel=WB_MEM; end
                OP_LH:  begin d_reg_write=1'b1; d_dest=dec_rt; d_uses_rs=1'b1; d_alu_src_imm=1'b1; d_mem_read=1'b1; d_mem_size=MS_HALF; d_mem_unsigned=1'b0; d_wb_sel=WB_MEM; end
                OP_LHU: begin d_reg_write=1'b1; d_dest=dec_rt; d_uses_rs=1'b1; d_alu_src_imm=1'b1; d_mem_read=1'b1; d_mem_size=MS_HALF; d_mem_unsigned=1'b1; d_wb_sel=WB_MEM; end
                OP_LW:  begin d_reg_write=1'b1; d_dest=dec_rt; d_uses_rs=1'b1; d_alu_src_imm=1'b1; d_mem_read=1'b1; d_mem_size=MS_WORD; d_wb_sel=WB_MEM; end
                OP_SB:  begin d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_src_imm=1'b1; d_mem_write=1'b1; d_mem_size=MS_BYTE; end
                OP_SH:  begin d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_src_imm=1'b1; d_mem_write=1'b1; d_mem_size=MS_HALF; end
                OP_SW:  begin d_uses_rs=1'b1; d_uses_rt=1'b1; d_alu_src_imm=1'b1; d_mem_write=1'b1; d_mem_size=MS_WORD; end
                default: begin d_reserved=1'b1; end
            endcase
        end
    end

    wire id_ctrl_taken = (d_is_jump || (d_is_branch && d_bcond_taken));
    wire [31:0] pc_plus4 = pc + 32'd4;
    wire [31:0] next_pc_normal = id_ctrl_taken ? d_branch_target : pc_plus4;

    // ---------------------------------------------------------------------
    // Hazard detection.
    // ---------------------------------------------------------------------
    wire id_is_branch_or_jr = d_is_branch || d_is_jump || d_is_eret;
    wire id_uses_hilo = d_hilo_read_hi || d_hilo_read_lo;
    wire pending_hilo_write = (id_ex_valid && (id_ex_hi_we || id_ex_lo_we)) ||
                              (ex_mem_valid && (ex_mem_hi_we || ex_mem_lo_we)) ||
                              (mem_wb_valid && (mem_wb_hi_we || mem_wb_lo_we));

    wire hazard_load_use = id_ex_valid && id_ex_mem_read && id_ex_reg_write && id_ex_dest != 5'd0 &&
                           ((d_uses_rs && id_ex_dest == dec_rs) || (d_uses_rt && id_ex_dest == dec_rt));
    wire hazard_branch_idex = id_is_branch_or_jr && id_ex_valid && id_ex_reg_write && id_ex_dest != 5'd0 &&
                              ((d_uses_rs && id_ex_dest == dec_rs) || (d_uses_rt && id_ex_dest == dec_rt));
    wire hazard_branch_load_exmem = id_is_branch_or_jr && ex_mem_valid && ex_mem_mem_read && ex_mem_reg_write && ex_mem_dest != 5'd0 &&
                              ((d_uses_rs && ex_mem_dest == dec_rs) || (d_uses_rt && ex_mem_dest == dec_rt));
    wire hazard_hilo = id_uses_hilo && pending_hilo_write;
    wire stall = hazard_load_use || hazard_branch_idex || hazard_branch_load_exmem || hazard_hilo;

    // ---------------------------------------------------------------------
    // ID/EX pipeline register.
    // ---------------------------------------------------------------------
    reg        id_ex_valid;
    reg [31:0] id_ex_pc;
    reg [31:0] id_ex_pc8;
    reg [31:0] id_ex_rs_value;
    reg [31:0] id_ex_rt_value;
    reg [31:0] id_ex_imm;
    reg [4:0]  id_ex_rs;
    reg [4:0]  id_ex_rt;
    reg [4:0]  id_ex_rd;
    reg [4:0]  id_ex_sa;
    reg [4:0]  id_ex_dest;
    reg        id_ex_reg_write;
    reg        id_ex_mem_read;
    reg        id_ex_mem_write;
    reg [1:0]  id_ex_mem_size;
    reg        id_ex_mem_unsigned;
    reg        id_ex_alu_src_imm;
    reg [4:0]  id_ex_alu_op;
    reg [2:0]  id_ex_wb_sel;
    reg        id_ex_overflow_check;
    reg        id_ex_shift_imm;
    reg        id_ex_hi_we;
    reg        id_ex_lo_we;
    reg        id_ex_hilo_read_hi;
    reg        id_ex_hilo_read_lo;
    reg        id_ex_cp0_read;
    reg        id_ex_cp0_write;
    reg [4:0]  id_ex_cp0_rd;
    reg [2:0]  id_ex_cp0_sel;
    reg        id_ex_syscall;
    reg        id_ex_break;
    reg        id_ex_reserved;

    // ---------------------------------------------------------------------
    // EX stage: forwarding + ALU + exception detection.
    // ---------------------------------------------------------------------
    reg [31:0] ex_rs_value_fwd;
    reg [31:0] ex_rt_value_fwd;
    wire [31:0] ex_alu_b = id_ex_alu_src_imm ? id_ex_imm : ex_rt_value_fwd;
    reg [31:0] ex_alu_result;
    reg [31:0] ex_hi_result;
    reg [31:0] ex_lo_result;
    reg        ex_overflow;
    reg        ex_exception;
    reg [4:0]  ex_exc_code;

    wire signed [31:0] ex_a_signed = ex_rs_value_fwd;
    wire signed [31:0] ex_b_signed = ex_alu_b;
    wire signed [31:0] ex_rt_signed = ex_rt_value_fwd;
    wire [4:0] ex_shift_amount = id_ex_shift_imm ? id_ex_sa : ex_rs_value_fwd[4:0];
    wire signed [63:0] signed_prod = $signed(ex_rs_value_fwd) * $signed(ex_rt_value_fwd);
    wire [63:0] unsigned_prod = {32'b0, ex_rs_value_fwd} * {32'b0, ex_rt_value_fwd};

    always @(*) begin
        ex_mem_forward_value = ex_mem_alu_result;
        case (ex_mem_wb_sel)
            WB_PC8:  ex_mem_forward_value = ex_mem_pc8;
            WB_HILO: ex_mem_forward_value = ex_mem_hilo_value;
            WB_CP0:  ex_mem_forward_value = ex_mem_cp0_rdata;
            default: ex_mem_forward_value = ex_mem_alu_result;
        endcase
    end

    always @(*) begin
        ex_rs_value_fwd = id_ex_rs_value;
        ex_rt_value_fwd = id_ex_rt_value;
        if (ex_mem_valid && ex_mem_reg_write && !ex_mem_mem_read && ex_mem_dest != 5'd0 && ex_mem_dest == id_ex_rs)
            ex_rs_value_fwd = ex_mem_forward_value;
        else if (mem_wb_valid && mem_wb_reg_write && mem_wb_dest != 5'd0 && mem_wb_dest == id_ex_rs)
            ex_rs_value_fwd = wb_data;

        if (ex_mem_valid && ex_mem_reg_write && !ex_mem_mem_read && ex_mem_dest != 5'd0 && ex_mem_dest == id_ex_rt)
            ex_rt_value_fwd = ex_mem_forward_value;
        else if (mem_wb_valid && mem_wb_reg_write && mem_wb_dest != 5'd0 && mem_wb_dest == id_ex_rt)
            ex_rt_value_fwd = wb_data;
    end

    always @(*) begin
        ex_alu_result = 32'd0;
        ex_hi_result = hi_reg;
        ex_lo_result = lo_reg;
        ex_overflow = 1'b0;
        case (id_ex_alu_op)
            ALU_ADD: begin
                ex_alu_result = ex_rs_value_fwd + ex_alu_b;
                ex_overflow = (~(ex_rs_value_fwd[31] ^ ex_alu_b[31])) & (ex_alu_result[31] ^ ex_rs_value_fwd[31]);
            end
            ALU_SUB: begin
                ex_alu_result = ex_rs_value_fwd - ex_alu_b;
                ex_overflow = (ex_rs_value_fwd[31] ^ ex_alu_b[31]) & (ex_alu_result[31] ^ ex_rs_value_fwd[31]);
            end
            ALU_AND:  ex_alu_result = ex_rs_value_fwd & ex_alu_b;
            ALU_OR:   ex_alu_result = ex_rs_value_fwd | ex_alu_b;
            ALU_XOR:  ex_alu_result = ex_rs_value_fwd ^ ex_alu_b;
            ALU_NOR:  ex_alu_result = ~(ex_rs_value_fwd | ex_alu_b);
            ALU_SLT:  ex_alu_result = (ex_a_signed < ex_b_signed) ? 32'd1 : 32'd0;
            ALU_SLTU: ex_alu_result = (ex_rs_value_fwd < ex_alu_b) ? 32'd1 : 32'd0;
            ALU_SLL:  ex_alu_result = ex_rt_value_fwd << ex_shift_amount;
            ALU_SRL:  ex_alu_result = ex_rt_value_fwd >> ex_shift_amount;
            ALU_SRA:  ex_alu_result = ex_rt_signed >>> ex_shift_amount;
            ALU_LUI:  ex_alu_result = {id_ex_imm[15:0], 16'b0};
            ALU_MULT: begin ex_lo_result = signed_prod[31:0]; ex_hi_result = signed_prod[63:32]; end
            ALU_MULTU:begin ex_lo_result = unsigned_prod[31:0]; ex_hi_result = unsigned_prod[63:32]; end
            ALU_DIV: begin
                if (ex_rt_value_fwd != 32'd0) begin
                    ex_lo_result = $signed(ex_rs_value_fwd) / $signed(ex_rt_value_fwd);
                    ex_hi_result = $signed(ex_rs_value_fwd) % $signed(ex_rt_value_fwd);
                end else begin
                    ex_lo_result = lo_reg;
                    ex_hi_result = hi_reg;
                end
            end
            ALU_DIVU: begin
                if (ex_rt_value_fwd != 32'd0) begin
                    ex_lo_result = ex_rs_value_fwd / ex_rt_value_fwd;
                    ex_hi_result = ex_rs_value_fwd % ex_rt_value_fwd;
                end else begin
                    ex_lo_result = lo_reg;
                    ex_hi_result = hi_reg;
                end
            end
            default: ex_alu_result = ex_rs_value_fwd + ex_alu_b;
        endcase
    end

    wire [31:0] cp0_read_data = (id_ex_cp0_rd == 5'd8)  ? cp0_badvaddr :
                                (id_ex_cp0_rd == 5'd9)  ? cp0_count    :
                                (id_ex_cp0_rd == 5'd12) ? cp0_status   :
                                (id_ex_cp0_rd == 5'd13) ? cp0_cause    :
                                (id_ex_cp0_rd == 5'd14) ? cp0_epc      : 32'd0;
    wire [31:0] ex_hilo_value = id_ex_hilo_read_hi ? hi_reg : lo_reg;

    always @(*) begin
        ex_exception = 1'b0;
        ex_exc_code = 5'd0;
        if (id_ex_valid && id_ex_reserved) begin
            ex_exception = 1'b1;
            ex_exc_code = EXC_RI;
        end else if (id_ex_valid && id_ex_syscall) begin
            ex_exception = 1'b1;
            ex_exc_code = EXC_SYS;
        end else if (id_ex_valid && id_ex_break) begin
            ex_exception = 1'b1;
            ex_exc_code = EXC_BP;
        end else if (id_ex_valid && id_ex_overflow_check && ex_overflow) begin
            ex_exception = 1'b1;
            ex_exc_code = EXC_OV;
        end
    end

    // ---------------------------------------------------------------------
    // EX/MEM pipeline register.
    // ---------------------------------------------------------------------
    reg        ex_mem_valid;
    reg [31:0] ex_mem_pc;
    reg [31:0] ex_mem_pc8;
    reg [31:0] ex_mem_alu_result;
    reg [31:0] ex_mem_rt_value;
    reg [31:0] ex_mem_hilo_value;
    reg [31:0] ex_mem_hi_result;
    reg [31:0] ex_mem_lo_result;
    reg [31:0] ex_mem_cp0_rdata;
    reg [31:0] ex_mem_cp0_wdata;
    reg [4:0]  ex_mem_dest;
    reg        ex_mem_reg_write;
    reg        ex_mem_mem_read;
    reg        ex_mem_mem_write;
    reg [1:0]  ex_mem_mem_size;
    reg        ex_mem_mem_unsigned;
    reg [2:0]  ex_mem_wb_sel;
    reg        ex_mem_hi_we;
    reg        ex_mem_lo_we;
    reg        ex_mem_cp0_write;
    reg [4:0]  ex_mem_cp0_rd;
    reg [2:0]  ex_mem_cp0_sel;
    reg        ex_mem_exception;
    reg [4:0]  ex_mem_exc_code;

    // MEM stage address check and store data alignment.
    wire mem_addr_err_load  = ex_mem_valid && ex_mem_mem_read &&
                              ((ex_mem_mem_size == MS_WORD && ex_mem_alu_result[1:0] != 2'b00) ||
                               (ex_mem_mem_size == MS_HALF && ex_mem_alu_result[0] != 1'b0));
    wire mem_addr_err_store = ex_mem_valid && ex_mem_mem_write &&
                              ((ex_mem_mem_size == MS_WORD && ex_mem_alu_result[1:0] != 2'b00) ||
                               (ex_mem_mem_size == MS_HALF && ex_mem_alu_result[0] != 1'b0));
    wire mem_exception = ex_mem_exception || mem_addr_err_load || mem_addr_err_store;
    wire [4:0] mem_exc_code = ex_mem_exception ? ex_mem_exc_code :
                              (mem_addr_err_store ? EXC_ADES : EXC_ADEL);
    wire [31:0] mem_badaddr = ex_mem_alu_result;

    assign dmem_addr = {ex_mem_alu_result[31:2], 2'b00};
    assign dmem_re   = ex_mem_valid && ex_mem_mem_read && !mem_exception;
    assign dmem_we   = ex_mem_valid && ex_mem_mem_write && !mem_exception;

    reg [31:0] store_data_aligned;
    always @(*) begin
        case (ex_mem_mem_size)
            MS_BYTE: begin
                case (ex_mem_alu_result[1:0])
                    2'd0: store_data_aligned = {24'd0, ex_mem_rt_value[7:0]};
                    2'd1: store_data_aligned = {16'd0, ex_mem_rt_value[7:0], 8'd0};
                    2'd2: store_data_aligned = {8'd0, ex_mem_rt_value[7:0], 16'd0};
                    default: store_data_aligned = {ex_mem_rt_value[7:0], 24'd0};
                endcase
            end
            MS_HALF: begin
                if (ex_mem_alu_result[1] == 1'b0)
                    store_data_aligned = {16'd0, ex_mem_rt_value[15:0]};
                else
                    store_data_aligned = {ex_mem_rt_value[15:0], 16'd0};
            end
            default: store_data_aligned = ex_mem_rt_value;
        endcase
    end
    assign dmem_wdata = store_data_aligned;

    // ---------------------------------------------------------------------
    // MEM/WB pipeline register.
    // ---------------------------------------------------------------------
    reg        mem_wb_valid;
    reg [31:0] mem_wb_pc;
    reg [31:0] mem_wb_pc8;
    reg [31:0] mem_wb_alu_result;
    reg [31:0] mem_wb_mem_rdata;
    reg [31:0] mem_wb_hilo_value;
    reg [31:0] mem_wb_hi_result;
    reg [31:0] mem_wb_lo_result;
    reg [31:0] mem_wb_cp0_rdata;
    reg [31:0] mem_wb_cp0_wdata;
    reg [4:0]  mem_wb_dest;
    reg        mem_wb_reg_write;
    reg        mem_wb_mem_read;
    reg [1:0]  mem_wb_mem_size;
    reg        mem_wb_mem_unsigned;
    reg [2:0]  mem_wb_wb_sel;
    reg        mem_wb_hi_we;
    reg        mem_wb_lo_we;
    reg        mem_wb_cp0_write;
    reg [4:0]  mem_wb_cp0_rd;
    reg [2:0]  mem_wb_cp0_sel;

    reg [31:0] load_ext_data;
    always @(*) begin
        case (mem_wb_mem_size)
            MS_BYTE: begin
                case (mem_wb_alu_result[1:0])
                    2'd0: load_ext_data = mem_wb_mem_unsigned ? {24'd0, mem_wb_mem_rdata[7:0]}   : {{24{mem_wb_mem_rdata[7]}},   mem_wb_mem_rdata[7:0]};
                    2'd1: load_ext_data = mem_wb_mem_unsigned ? {24'd0, mem_wb_mem_rdata[15:8]}  : {{24{mem_wb_mem_rdata[15]}},  mem_wb_mem_rdata[15:8]};
                    2'd2: load_ext_data = mem_wb_mem_unsigned ? {24'd0, mem_wb_mem_rdata[23:16]} : {{24{mem_wb_mem_rdata[23]}}, mem_wb_mem_rdata[23:16]};
                    default: load_ext_data = mem_wb_mem_unsigned ? {24'd0, mem_wb_mem_rdata[31:24]} : {{24{mem_wb_mem_rdata[31]}}, mem_wb_mem_rdata[31:24]};
                endcase
            end
            MS_HALF: begin
                if (mem_wb_alu_result[1] == 1'b0)
                    load_ext_data = mem_wb_mem_unsigned ? {16'd0, mem_wb_mem_rdata[15:0]} : {{16{mem_wb_mem_rdata[15]}}, mem_wb_mem_rdata[15:0]};
                else
                    load_ext_data = mem_wb_mem_unsigned ? {16'd0, mem_wb_mem_rdata[31:16]} : {{16{mem_wb_mem_rdata[31]}}, mem_wb_mem_rdata[31:16]};
            end
            default: load_ext_data = mem_wb_mem_rdata;
        endcase
    end

    always @(*) begin
        wb_data = mem_wb_alu_result;
        case (mem_wb_wb_sel)
            WB_MEM: wb_data = load_ext_data;
            WB_PC8: wb_data = mem_wb_pc8;
            WB_HILO: wb_data = mem_wb_hilo_value;
            WB_CP0: wb_data = mem_wb_cp0_rdata;
            default: wb_data = mem_wb_alu_result;
        endcase
        wb_reg_write = mem_wb_valid && mem_wb_reg_write;
        wb_dest = mem_wb_dest;
    end

    // ---------------------------------------------------------------------
    // Sequential state update.
    // ---------------------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pc <= RESET_PC;
            if_pc_d <= RESET_PC;
            if_id_valid <= 1'b0;
            if_id_pc <= 32'd0;
            if_id_instr <= 32'd0;

            id_ex_valid <= 1'b0;
            id_ex_pc <= 32'd0;
            id_ex_pc8 <= 32'd0;
            id_ex_rs_value <= 32'd0;
            id_ex_rt_value <= 32'd0;
            id_ex_imm <= 32'd0;
            id_ex_rs <= 5'd0;
            id_ex_rt <= 5'd0;
            id_ex_rd <= 5'd0;
            id_ex_sa <= 5'd0;
            id_ex_dest <= 5'd0;
            id_ex_reg_write <= 1'b0;
            id_ex_mem_read <= 1'b0;
            id_ex_mem_write <= 1'b0;
            id_ex_mem_size <= MS_WORD;
            id_ex_mem_unsigned <= 1'b0;
            id_ex_alu_src_imm <= 1'b0;
            id_ex_alu_op <= ALU_ADD;
            id_ex_wb_sel <= WB_ALU;
            id_ex_overflow_check <= 1'b0;
            id_ex_shift_imm <= 1'b0;
            id_ex_hi_we <= 1'b0;
            id_ex_lo_we <= 1'b0;
            id_ex_hilo_read_hi <= 1'b0;
            id_ex_hilo_read_lo <= 1'b0;
            id_ex_cp0_read <= 1'b0;
            id_ex_cp0_write <= 1'b0;
            id_ex_cp0_rd <= 5'd0;
            id_ex_cp0_sel <= 3'd0;
            id_ex_syscall <= 1'b0;
            id_ex_break <= 1'b0;
            id_ex_reserved <= 1'b0;

            ex_mem_valid <= 1'b0;
            ex_mem_pc <= 32'd0;
            ex_mem_pc8 <= 32'd0;
            ex_mem_alu_result <= 32'd0;
            ex_mem_rt_value <= 32'd0;
            ex_mem_hilo_value <= 32'd0;
            ex_mem_hi_result <= 32'd0;
            ex_mem_lo_result <= 32'd0;
            ex_mem_cp0_rdata <= 32'd0;
            ex_mem_cp0_wdata <= 32'd0;
            ex_mem_dest <= 5'd0;
            ex_mem_reg_write <= 1'b0;
            ex_mem_mem_read <= 1'b0;
            ex_mem_mem_write <= 1'b0;
            ex_mem_mem_size <= MS_WORD;
            ex_mem_mem_unsigned <= 1'b0;
            ex_mem_wb_sel <= WB_ALU;
            ex_mem_hi_we <= 1'b0;
            ex_mem_lo_we <= 1'b0;
            ex_mem_cp0_write <= 1'b0;
            ex_mem_cp0_rd <= 5'd0;
            ex_mem_cp0_sel <= 3'd0;
            ex_mem_exception <= 1'b0;
            ex_mem_exc_code <= 5'd0;

            mem_wb_valid <= 1'b0;
            mem_wb_pc <= 32'd0;
            mem_wb_pc8 <= 32'd0;
            mem_wb_alu_result <= 32'd0;
            mem_wb_mem_rdata <= 32'd0;
            mem_wb_hilo_value <= 32'd0;
            mem_wb_hi_result <= 32'd0;
            mem_wb_lo_result <= 32'd0;
            mem_wb_cp0_rdata <= 32'd0;
            mem_wb_cp0_wdata <= 32'd0;
            mem_wb_dest <= 5'd0;
            mem_wb_reg_write <= 1'b0;
            mem_wb_mem_read <= 1'b0;
            mem_wb_mem_size <= MS_WORD;
            mem_wb_mem_unsigned <= 1'b0;
            mem_wb_wb_sel <= WB_ALU;
            mem_wb_hi_we <= 1'b0;
            mem_wb_lo_we <= 1'b0;
            mem_wb_cp0_write <= 1'b0;
            mem_wb_cp0_rd <= 5'd0;
            mem_wb_cp0_sel <= 3'd0;

            hi_reg <= 32'd0;
            lo_reg <= 32'd0;
            cp0_badvaddr <= 32'd0;
            cp0_count <= 32'd0;
            cp0_status <= 32'h0040_0000; // BEV is fixed to 1 in the contest subset
            cp0_cause <= 32'd0;
            cp0_epc <= 32'd0;
            cp0_count_tick <= 1'b0;
        end else begin
            cp0_count_tick <= ~cp0_count_tick;
            if (cp0_count_tick) cp0_count <= cp0_count + 32'd1;

            // Normal WB commits of HI/LO and CP0. GPR commit occurs in regfile module.
            if (mem_wb_valid && mem_wb_hi_we) hi_reg <= mem_wb_hi_result;
            if (mem_wb_valid && mem_wb_lo_we) lo_reg <= mem_wb_lo_result;
            if (mem_wb_valid && mem_wb_cp0_write) begin
                case (mem_wb_cp0_rd)
                    5'd8:  cp0_badvaddr <= mem_wb_cp0_wdata;
                    5'd9:  cp0_count    <= mem_wb_cp0_wdata;
                    5'd12: cp0_status   <= (mem_wb_cp0_wdata & 32'h0000_FF03) | 32'h0040_0000;
                    5'd13: cp0_cause    <= mem_wb_cp0_wdata;
                    5'd14: cp0_epc      <= mem_wb_cp0_wdata;
                    default: ;
                endcase
            end

            if (mem_exception) begin
                pc <= EXC_VEC;
                if_pc_d <= EXC_VEC;
                if_id_valid <= 1'b0;
                id_ex_valid <= 1'b0;
                ex_mem_valid <= 1'b0;
                mem_wb_valid <= 1'b0;
                cp0_status[1] <= 1'b1;              // EXL
                cp0_cause[6:2] <= mem_exc_code;
                cp0_epc <= ex_mem_pc;
                if (mem_addr_err_load || mem_addr_err_store) cp0_badvaddr <= mem_badaddr;
            end else if (ex_exception) begin
                pc <= EXC_VEC;
                if_pc_d <= EXC_VEC;
                if_id_valid <= 1'b0;
                id_ex_valid <= 1'b0;
                ex_mem_valid <= 1'b0;
                mem_wb_valid <= 1'b0;
                cp0_status[1] <= 1'b1;
                cp0_cause[6:2] <= ex_exc_code;
                cp0_epc <= id_ex_pc;
            end else if (if_id_valid && d_is_eret && !stall) begin
                pc <= cp0_epc;
                if_pc_d <= cp0_epc;
                if_id_valid <= 1'b0;
                id_ex_valid <= 1'b0;
                ex_mem_valid <= 1'b0;
                mem_wb_valid <= 1'b0;
                cp0_status[1] <= 1'b0;
            end else begin
                // MEM/WB advances every cycle unless an exception flushes the pipe.
                mem_wb_valid <= ex_mem_valid;
                mem_wb_pc <= ex_mem_pc;
                mem_wb_pc8 <= ex_mem_pc8;
                mem_wb_alu_result <= ex_mem_alu_result;
                mem_wb_mem_rdata <= dmem_rdata;
                mem_wb_hilo_value <= ex_mem_hilo_value;
                mem_wb_hi_result <= ex_mem_hi_result;
                mem_wb_lo_result <= ex_mem_lo_result;
                mem_wb_cp0_rdata <= ex_mem_cp0_rdata;
                mem_wb_cp0_wdata <= ex_mem_cp0_wdata;
                mem_wb_dest <= ex_mem_dest;
                mem_wb_reg_write <= ex_mem_reg_write;
                mem_wb_mem_read <= ex_mem_mem_read;
                mem_wb_mem_size <= ex_mem_mem_size;
                mem_wb_mem_unsigned <= ex_mem_mem_unsigned;
                mem_wb_wb_sel <= ex_mem_wb_sel;
                mem_wb_hi_we <= ex_mem_hi_we;
                mem_wb_lo_we <= ex_mem_lo_we;
                mem_wb_cp0_write <= ex_mem_cp0_write;
                mem_wb_cp0_rd <= ex_mem_cp0_rd;
                mem_wb_cp0_sel <= ex_mem_cp0_sel;

                if (stall) begin
                    // Hold fetch and decode; inject a bubble into EX.
                    pc <= pc;
                    if_pc_d <= if_pc_d;
                    if_id_valid <= if_id_valid;
                    if_id_pc <= if_id_pc;
                    if_id_instr <= if_id_instr;

                    id_ex_valid <= 1'b0;
                    id_ex_reg_write <= 1'b0;
                    id_ex_mem_read <= 1'b0;
                    id_ex_mem_write <= 1'b0;
                    id_ex_hi_we <= 1'b0;
                    id_ex_lo_we <= 1'b0;
                    id_ex_cp0_write <= 1'b0;
                    id_ex_syscall <= 1'b0;
                    id_ex_break <= 1'b0;
                    id_ex_reserved <= 1'b0;
                end else begin
                    pc <= next_pc_normal;
                    if_pc_d <= pc;
                    if_id_valid <= 1'b1;
                    if_id_pc <= if_pc_d;
                    if_id_instr <= instr;

                    id_ex_valid <= if_id_valid && !d_is_eret;
                    id_ex_pc <= if_id_pc;
                    id_ex_pc8 <= if_id_pc + 32'd8;
                    id_ex_rs_value <= rf_rs_data;
                    id_ex_rt_value <= rf_rt_data;
                    id_ex_imm <= dec_imm_ext;
                    id_ex_rs <= dec_rs;
                    id_ex_rt <= dec_rt;
                    id_ex_rd <= dec_rd;
                    id_ex_sa <= dec_sa;
                    id_ex_dest <= d_dest;
                    id_ex_reg_write <= d_reg_write;
                    id_ex_mem_read <= d_mem_read;
                    id_ex_mem_write <= d_mem_write;
                    id_ex_mem_size <= d_mem_size;
                    id_ex_mem_unsigned <= d_mem_unsigned;
                    id_ex_alu_src_imm <= d_alu_src_imm;
                    id_ex_alu_op <= d_alu_op;
                    id_ex_wb_sel <= d_wb_sel;
                    id_ex_overflow_check <= d_overflow_check;
                    id_ex_shift_imm <= d_shift_imm;
                    id_ex_hi_we <= d_hi_we;
                    id_ex_lo_we <= d_lo_we;
                    id_ex_hilo_read_hi <= d_hilo_read_hi;
                    id_ex_hilo_read_lo <= d_hilo_read_lo;
                    id_ex_cp0_read <= d_cp0_read;
                    id_ex_cp0_write <= d_cp0_write;
                    id_ex_cp0_rd <= d_cp0_rd;
                    id_ex_cp0_sel <= d_cp0_sel;
                    id_ex_syscall <= d_syscall;
                    id_ex_break <= d_break;
                    id_ex_reserved <= d_reserved;
                end

                // ID/EX -> EX/MEM always advances from the current EX stage.
                ex_mem_valid <= id_ex_valid;
                ex_mem_pc <= id_ex_pc;
                ex_mem_pc8 <= id_ex_pc8;
                ex_mem_alu_result <= ex_alu_result;
                ex_mem_rt_value <= ex_rt_value_fwd;
                ex_mem_hilo_value <= ex_hilo_value;
                ex_mem_hi_result <= ex_hi_result;
                ex_mem_lo_result <= ex_lo_result;
                ex_mem_cp0_rdata <= cp0_read_data;
                ex_mem_cp0_wdata <= ex_rt_value_fwd;
                ex_mem_dest <= id_ex_dest;
                ex_mem_reg_write <= id_ex_reg_write;
                ex_mem_mem_read <= id_ex_mem_read;
                ex_mem_mem_write <= id_ex_mem_write;
                ex_mem_mem_size <= id_ex_mem_size;
                ex_mem_mem_unsigned <= id_ex_mem_unsigned;
                ex_mem_wb_sel <= id_ex_wb_sel;
                ex_mem_hi_we <= id_ex_hi_we;
                ex_mem_lo_we <= id_ex_lo_we;
                ex_mem_cp0_write <= id_ex_cp0_write;
                ex_mem_cp0_rd <= id_ex_cp0_rd;
                ex_mem_cp0_sel <= id_ex_cp0_sel;
                ex_mem_exception <= ex_exception;
                ex_mem_exc_code <= ex_exc_code;
            end
        end
    end
endmodule

module cpu_yellow_regfile(
    input             clk,
    input             rst_n,
    input             we,
    input      [4:0]  waddr,
    input      [31:0] wdata,
    input      [4:0]  raddr1,
    input      [4:0]  raddr2,
    output     [31:0] rdata1,
    output     [31:0] rdata2
);
    integer i;
    reg [31:0] regs [0:31] /* verilator public_flat_rw */;

    assign rdata1 = (raddr1 == 5'd0) ? 32'd0 : regs[raddr1];
    assign rdata2 = (raddr2 == 5'd0) ? 32'd0 : regs[raddr2];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (i = 0; i < 32; i = i + 1) regs[i] <= 32'd0;
        end else begin
            regs[0] <= 32'd0;
            if (we && waddr != 5'd0) regs[waddr] <= wdata;
        end
    end
endmodule
