`timescale 1ns/1ps

module cpu_yellow_top_tb;
    reg clk;
    reg rst_n;
    reg [31:0] instr;
    wire [31:0] instr_addr;
    wire [31:0] dmem_addr;
    wire [31:0] dmem_wdata;
    reg [31:0] dmem_rdata;
    wire dmem_we;
    wire dmem_re;

    cpu_yellow_top dut (
        .clk(clk),
        .rst_n(rst_n),
        .instr(instr),
        .instr_addr(instr_addr),
        .dmem_addr(dmem_addr),
        .dmem_wdata(dmem_wdata),
        .dmem_rdata(dmem_rdata),
        .dmem_we(dmem_we),
        .dmem_re(dmem_re)
    );

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    initial begin
        rst_n = 1'b0;
        instr = 32'd0;
        dmem_rdata = 32'd0;
        #50 rst_n = 1'b1;
        #2000 $finish;
    end
endmodule
