import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, ReadOnly, Timer

from tests.mips_encode import *


def _int(sig):
    return int(sig.value) & 0xFFFFFFFF


async def reset_dut(dut):
    dut.rst_n.value = 0
    dut.instr.value = 0
    dut.dmem_rdata.value = 0
    await RisingEdge(dut.clk)
    await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    await RisingEdge(dut.clk)


class SyncMemory:
    def __init__(self, dut, imem=None, dmem=None):
        self.dut = dut
        self.imem = dict(imem or {})
        self.dmem = dict(dmem or {})  # word-addressed by aligned byte address
        self.last_iaddr = RESET_PC
        self.last_daddr = 0
        self.last_dre = 0

    def read_word(self, mem, addr):
        return mem.get(addr & 0xFFFFFFFC, 0)

    def write_store(self, addr, wdata, size):
        aligned = addr & 0xFFFFFFFC
        old = self.dmem.get(aligned, 0)
        lane = addr & 3
        if size == 0:      # byte
            shift = lane * 8
            mask = 0xFF << shift
            new = (old & ~mask) | (wdata & mask)
        elif size == 1:    # half
            shift = (2 if (lane & 2) else 0) * 8
            mask = 0xFFFF << shift
            new = (old & ~mask) | (wdata & mask)
        else:
            new = wdata & 0xFFFFFFFF
        self.dmem[aligned] = new & 0xFFFFFFFF

    async def run(self):
        while True:
            await RisingEdge(self.dut.clk)
            await ReadOnly()

            # Store occurs on this edge in the external memory.
            if int(self.dut.dmem_we.value):
                try:
                    size = int(self.dut.ex_mem_mem_size.value)
                    eff_addr = int(self.dut.ex_mem_alu_result.value) & 0xFFFFFFFF
                except Exception:
                    size = 2
                    eff_addr = _int(self.dut.dmem_addr)
                self.write_store(eff_addr, _int(self.dut.dmem_wdata), size)

            # One-cycle delayed read response for both instruction and data ports.
            self.dut.instr.value = self.read_word(self.imem, self.last_iaddr)
            self.dut.dmem_rdata.value = self.read_word(self.dmem, self.last_daddr) if self.last_dre else self.read_word(self.dmem, self.last_daddr)
            self.last_iaddr = _int(self.dut.instr_addr)
            self.last_daddr = _int(self.dut.dmem_addr)
            self.last_dre = int(self.dut.dmem_re.value)


async def run_prog(dut, words, cycles=80, dmem=None):
    cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())
    mem = SyncMemory(dut, load_program(words), dmem)
    cocotb.start_soon(mem.run())
    await reset_dut(dut)
    for _ in range(cycles):
        await RisingEdge(dut.clk)
    return mem


def reg(dut, idx):
    return int(dut.u_regfile.regs[idx].value) & 0xFFFFFFFF


@cocotb.test()
async def test_arithmetic_logic_shift_and_forwarding(dut):
    words = [
        addiu(1, 0, 5),          # r1=5
        addiu(2, 0, 7),          # r2=7
        addu(3, 1, 2),           # r3=12, forwarding
        subu(4, 3, 1),           # r4=7
        and_(5, 3, 4),           # 12&7=4
        or_(6, 5, 1),            # 5
        xor(7, 6, 2),            # 2
        nor(8, 0, 0),            # ffffffff
        slt(9, 1, 2),            # 1
        sltu(10, 2, 1),          # 0
        sll(11, 1, 3),           # 40
        srl(12, 11, 1),          # 20
        sra(13, 8, 4),           # ffffffff
        addiu(14, 0, 2),
        sllv(15, 1, 14),         # 20
        srlv(16, 11, 14),        # 10
        srav(17, 8, 14),         # ffffffff
        lui(18, 0x1234),
        ori(18, 18, 0x5678),
        andi(19, 18, 0x00ff),
        xori(20, 19, 0x00ff),
        slti(21, 1, 6),
        sltiu(22, 1, -1),
    ] + [nop()] * 10
    await run_prog(dut, words, cycles=90)
    assert reg(dut, 3) == 12
    assert reg(dut, 4) == 7
    assert reg(dut, 5) == 4
    assert reg(dut, 8) == 0xFFFFFFFF
    assert reg(dut, 11) == 40
    assert reg(dut, 17) == 0xFFFFFFFF
    assert reg(dut, 18) == 0x12345678
    assert reg(dut, 19) == 0x78
    assert reg(dut, 20) == 0x87
    assert reg(dut, 21) == 1
    assert reg(dut, 22) == 1


@cocotb.test()
async def test_load_store_sign_extension_and_load_use(dut):
    base = 0xBFC10000
    words = [
        lui(1, base >> 16),
        ori(1, 1, base & 0xFFFF),
        lui(2, 0xA1B2),
        ori(2, 2, 0xC3D4),
        sw(2, 0, 1),
        lw(3, 0, 1),             # load
        addu(4, 3, 2),           # load-use must stall then forward
        lb(5, 0, 1),             # 0xD4 -> signed -44
        lbu(6, 0, 1),
        lh(7, 0, 1),             # 0xC3D4 -> signed
        lhu(8, 0, 1),
        addiu(9, 0, 0x77),
        sb(9, 1, 1),
        addiu(10, 0, 0x1234),
        sh(10, 2, 1),
        lw(11, 0, 1),
    ] + [nop()] * 12
    mem = await run_prog(dut, words, cycles=100)
    assert reg(dut, 3) == 0xA1B2C3D4
    assert reg(dut, 4) == ((0xA1B2C3D4 + 0xA1B2C3D4) & 0xFFFFFFFF)
    assert reg(dut, 5) == 0xFFFFFFD4
    assert reg(dut, 6) == 0xD4
    assert reg(dut, 7) == 0xFFFFC3D4
    assert reg(dut, 8) == 0xC3D4
    assert mem.dmem[base] == 0x123477D4
    assert reg(dut, 11) == 0x123477D4


@cocotb.test()
async def test_branch_jump_link_and_delay_slot(dut):
    # Branch offset is relative to PC+4. Delay slot is always executed.
    target = RESET_PC + 0x30
    words = [
        addiu(1, 0, 1),          # 0
        beq(1, 1, 2),            # 4 -> target 0x10
        addiu(2, 0, 0x22),       # 8 delay slot, must execute
        addiu(3, 0, 0x33),       # c skipped
        addiu(4, 0, 0x44),       # 10 target
        bne(1, 1, 1),            # not taken
        addiu(5, 0, 0x55),       # delay slot executes
        jal(target),             # 1c
        addiu(6, 0, 0x66),       # 20 jal delay slot executes
        addiu(7, 0, 0x77),       # 24 skipped by jal
        nop(),                   # 28
        nop(),                   # 2c
        addiu(8, 0, 0x88),       # 30 target
        jr(31),                  # 34 return to 0x24? link PC+8 = 0x24
        addiu(9, 0, 0x99),       # 38 jr delay slot
        addiu(10, 0, 0xaa),      # 3c after return path may execute after return target sequence
    ] + [nop()] * 20
    await run_prog(dut, words, cycles=120)
    assert reg(dut, 2) == 0x22
    assert reg(dut, 3) == 0
    assert reg(dut, 4) == 0x44
    assert reg(dut, 5) == 0x55
    assert reg(dut, 6) == 0x66
    assert reg(dut, 8) == 0x88
    assert reg(dut, 9) == 0x99
    assert reg(dut, 31) == (RESET_PC + 0x24)


@cocotb.test()
async def test_hilo_mult_div_and_moves(dut):
    words = [
        addiu(1, 0, 6),
        addiu(2, 0, 4),
        mult(1, 2),
        mflo(3),
        mfhi(4),
        div(1, 2),
        mflo(5),
        mfhi(6),
        addiu(7, 0, 0x1234),
        mthi(7),
        mtlo(1),
        mfhi(8),
        mflo(9),
        multu(7, 2),
        mflo(10),
        divu(7, 2),
        mflo(11),
        mfhi(12),
    ] + [nop()] * 16
    await run_prog(dut, words, cycles=140)
    assert reg(dut, 3) == 24
    assert reg(dut, 4) == 0
    assert reg(dut, 5) == 1
    assert reg(dut, 6) == 2
    assert reg(dut, 8) == 0x1234
    assert reg(dut, 9) == 6
    assert reg(dut, 10) == 0x48D0
    assert reg(dut, 11) == 0x91A
    assert reg(dut, 12) == 0


@cocotb.test()
async def test_exception_cp0_and_eret(dut):
    # Main: trigger overflow. Exception vector reads EPC/Cause, advances EPC by 4, returns.
    main = [
        lui(1, 0x7fff),
        ori(1, 1, 0xffff),
        addi(2, 1, 1),           # overflow -> exception at this PC
        addiu(3, 0, 0x33),       # should execute after eret returns to EPC+4
        nop(), nop(), nop(), nop(),
    ]
    # Fill until vector offset 0x380/4.
    pad_len = (EXC_VEC - RESET_PC) // 4 - len(main)
    vector = [
        mfc0(10, 14),            # EPC
        mfc0(11, 13),            # Cause
        addiu(10, 10, 4),
        mtc0(10, 14),
        eret(),
        nop(),
    ]
    words = main + [nop()] * pad_len + vector + [nop()] * 12
    await run_prog(dut, words, cycles=180)
    assert reg(dut, 3) == 0x33
    assert reg(dut, 10) == (RESET_PC + 0x0c)  # EPC adjusted by handler
    assert ((reg(dut, 11) >> 2) & 0x1f) == 12
    assert int(dut.cp0_status.value) & 0x2 == 0
