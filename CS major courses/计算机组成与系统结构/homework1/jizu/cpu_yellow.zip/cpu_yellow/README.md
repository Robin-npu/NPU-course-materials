# CPU_YELLOW 五级流水线 MIPS 处理器

本工程实现 `CPUYellow_task.md` 中规定的 `cpu_yellow_top` 顶层接口，采用 IF/ID/EX/MEM/WB 五级流水线，使用 Verilog 描述，并提供 Verilator + Cocotb 验证框架。

## 目录

```text
cpu_red/
├── src/rtl/cpu_yellow_top.v       # RTL 顶层与寄存器堆
├── src/tb/test_cpu_yellow.py      # Cocotb 验证用例
├── src/tb/cpu_yellow_top_tb.sv    # 简单 SV TB 壳
├── tests/mips_encode.py           # MIPS 指令编码工具
├── tools/run_verilator.sh         # Verilator 仿真脚本
├── doc/                           # 设计/验证/总结报告
├── appendix/                      # 覆盖率与中间结果
└── Makefile
```

## 运行

```bash
conda activate cpu_red
cd cpu_red
make SIM=verilator TOPLEVEL=cpu_yellow_top MODULE=test_cpu_yellow
make coverage-report
```

也可以直接执行：

```bash
./tools/run_verilator.sh
```

## 重要说明

任务要求顶层接口不得增减信号，因此没有 `dmem_be[3:0]` 或 `dmem_size` 输出。RTL 对 `SB/SH` 输出按字节 lane 移位后的 `dmem_wdata`；Cocotb memory model 会通过层次化信号读取内部 `ex_mem_mem_size` 和有效地址低位完成字节/半字写入。若后续需要接入真实 FPGA Block RAM，建议在外部 wrapper 中增加 byte-enable，或将写掩码编码进数据存储器适配层。
