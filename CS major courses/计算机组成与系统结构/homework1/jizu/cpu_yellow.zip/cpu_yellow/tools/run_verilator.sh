#!/usr/bin/env bash
set -euo pipefail
source "${CONDA_PREFIX:-}/etc/profile.d/conda.sh" 2>/dev/null || source ~/miniconda3/etc/profile.d/conda.sh 2>/dev/null || true
conda activate cpu_red 2>/dev/null || echo "[WARN] conda env cpu_red not activated; using current shell environment."
make SIM=verilator TOPLEVEL=cpu_yellow_top MODULE=test_cpu_yellow
make coverage-report || true
