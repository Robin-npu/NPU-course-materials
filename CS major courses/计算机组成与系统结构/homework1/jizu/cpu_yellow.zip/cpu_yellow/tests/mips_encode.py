"""Small MIPS encoder used by cocotb tests for CPU_YELLOW."""
RESET_PC = 0xBFC00000
EXC_VEC = 0xBFC00380

def u32(x): return x & 0xFFFFFFFF
def imm16(x): return x & 0xFFFF

def r(rs, rt, rd, sh, fn): return ((rs&31)<<21)|((rt&31)<<16)|((rd&31)<<11)|((sh&31)<<6)|(fn&63)
def i(op, rs, rt, imm): return ((op&63)<<26)|((rs&31)<<21)|((rt&31)<<16)|imm16(imm)
def j(op, target): return ((op&63)<<26)|(((target >> 2) & 0x03FFFFFF))

def nop(): return 0

def add(rd, rs, rt): return r(rs, rt, rd, 0, 0x20)
def addu(rd, rs, rt): return r(rs, rt, rd, 0, 0x21)
def sub(rd, rs, rt): return r(rs, rt, rd, 0, 0x22)
def subu(rd, rs, rt): return r(rs, rt, rd, 0, 0x23)
def slt(rd, rs, rt): return r(rs, rt, rd, 0, 0x2a)
def sltu(rd, rs, rt): return r(rs, rt, rd, 0, 0x2b)
def and_(rd, rs, rt): return r(rs, rt, rd, 0, 0x24)
def or_(rd, rs, rt): return r(rs, rt, rd, 0, 0x25)
def xor(rd, rs, rt): return r(rs, rt, rd, 0, 0x26)
def nor(rd, rs, rt): return r(rs, rt, rd, 0, 0x27)
def sll(rd, rt, sh): return r(0, rt, rd, sh, 0x00)
def srl(rd, rt, sh): return r(0, rt, rd, sh, 0x02)
def sra(rd, rt, sh): return r(0, rt, rd, sh, 0x03)
def sllv(rd, rt, rs): return r(rs, rt, rd, 0, 0x04)
def srlv(rd, rt, rs): return r(rs, rt, rd, 0, 0x06)
def srav(rd, rt, rs): return r(rs, rt, rd, 0, 0x07)
def jr(rs): return r(rs, 0, 0, 0, 0x08)
def jalr(rd, rs): return r(rs, 0, rd, 0, 0x09)
def mfhi(rd): return r(0, 0, rd, 0, 0x10)
def mthi(rs): return r(rs, 0, 0, 0, 0x11)
def mflo(rd): return r(0, 0, rd, 0, 0x12)
def mtlo(rs): return r(rs, 0, 0, 0, 0x13)
def mult(rs, rt): return r(rs, rt, 0, 0, 0x18)
def multu(rs, rt): return r(rs, rt, 0, 0, 0x19)
def div(rs, rt): return r(rs, rt, 0, 0, 0x1a)
def divu(rs, rt): return r(rs, rt, 0, 0, 0x1b)
def syscall(): return 0x0000000c
def break_(): return 0x0000000d

def addi(rt, rs, imm): return i(0x08, rs, rt, imm)
def addiu(rt, rs, imm): return i(0x09, rs, rt, imm)
def slti(rt, rs, imm): return i(0x0a, rs, rt, imm)
def sltiu(rt, rs, imm): return i(0x0b, rs, rt, imm)
def andi(rt, rs, imm): return i(0x0c, rs, rt, imm)
def ori(rt, rs, imm): return i(0x0d, rs, rt, imm)
def xori(rt, rs, imm): return i(0x0e, rs, rt, imm)
def lui(rt, imm): return i(0x0f, 0, rt, imm)
def lb(rt, off, base): return i(0x20, base, rt, off)
def lh(rt, off, base): return i(0x21, base, rt, off)
def lw(rt, off, base): return i(0x23, base, rt, off)
def lbu(rt, off, base): return i(0x24, base, rt, off)
def lhu(rt, off, base): return i(0x25, base, rt, off)
def sb(rt, off, base): return i(0x28, base, rt, off)
def sh(rt, off, base): return i(0x29, base, rt, off)
def sw(rt, off, base): return i(0x2b, base, rt, off)
def beq(rs, rt, off): return i(0x04, rs, rt, off)
def bne(rs, rt, off): return i(0x05, rs, rt, off)
def blez(rs, off): return i(0x06, rs, 0, off)
def bgtz(rs, off): return i(0x07, rs, 0, off)
def bltz(rs, off): return i(0x01, rs, 0x00, off)
def bgez(rs, off): return i(0x01, rs, 0x01, off)
def bltzal(rs, off): return i(0x01, rs, 0x10, off)
def bgezal(rs, off): return i(0x01, rs, 0x11, off)
def j_(target): return j(0x02, target)
def jal(target): return j(0x03, target)
def mfc0(rt, rd, sel=0): return (0x10<<26)|(0<<21)|((rt&31)<<16)|((rd&31)<<11)|(sel&7)
def mtc0(rt, rd, sel=0): return (0x10<<26)|(4<<21)|((rt&31)<<16)|((rd&31)<<11)|(sel&7)
def eret(): return 0x42000018

def load_program(words, base=RESET_PC):
    return {base + i*4: u32(w) for i, w in enumerate(words)}
