# CPUYellow 指令覆盖计划

| 类别 | 指令 | 覆盖程序/测试 | 检查点 |
|---|---|---|---|
| 算术 | ADD | all_instr_smoke / 建议单测 | 非溢出写回、溢出异常 |
| 算术 | ADDI | exception_cp0 | 溢出异常、EPC/Cause |
| 算术 | ADDU | arithmetic_logic_shift | 前递后结果正确 |
| 算术 | ADDIU | 多个测试 | 立即数符号扩展 |
| 算术 | SUB | all_instr_smoke / 建议单测 | 非溢出写回、溢出异常 |
| 算术 | SUBU | arithmetic_logic_shift | 结果正确 |
| 算术 | SLT | arithmetic_logic_shift | 有符号比较 |
| 算术 | SLTI | arithmetic_logic_shift | 有符号立即数比较 |
| 算术 | SLTU | arithmetic_logic_shift | 无符号比较 |
| 算术 | SLTIU | arithmetic_logic_shift | 立即数符号扩展后无符号比较 |
| 算术 | DIV | hilo_mult_div | LO=商，HI=余数 |
| 算术 | DIVU | hilo_mult_div | 无符号商余数 |
| 算术 | MULT | hilo_mult_div | 乘积写 HI/LO |
| 算术 | MULTU | hilo_mult_div | 无符号乘积写 HI/LO |
| 逻辑 | AND | arithmetic_logic_shift | 位与 |
| 逻辑 | ANDI | arithmetic_logic_shift | 零扩展立即数 |
| 逻辑 | LUI | arithmetic_logic_shift | 高 16 位加载 |
| 逻辑 | NOR | arithmetic_logic_shift | 位或非 |
| 逻辑 | OR | arithmetic_logic_shift | 位或 |
| 逻辑 | ORI | arithmetic_logic_shift | 零扩展立即数 |
| 逻辑 | XOR | arithmetic_logic_shift | 位异或 |
| 逻辑 | XORI | arithmetic_logic_shift | 零扩展立即数 |
| 移位 | SLL | arithmetic_logic_shift | 立即数左移 |
| 移位 | SLLV | arithmetic_logic_shift | 变量左移 |
| 移位 | SRA | arithmetic_logic_shift | 算术右移符号扩展 |
| 移位 | SRAV | arithmetic_logic_shift | 变量算术右移 |
| 移位 | SRL | arithmetic_logic_shift | 逻辑右移 |
| 移位 | SRLV | arithmetic_logic_shift | 变量逻辑右移 |
| 分支跳转 | BEQ | branch_jump_link | taken + delay slot |
| 分支跳转 | BNE | branch_jump_link | not-taken + delay slot |
| 分支跳转 | BGEZ | all_instr_smoke / 可扩展单测 | 条件成立跳转 |
| 分支跳转 | BGTZ | all_instr_smoke / 可扩展单测 | 条件成立跳转 |
| 分支跳转 | BLEZ | all_instr_smoke / 可扩展单测 | 零值跳转 |
| 分支跳转 | BLTZ | all_instr_smoke / 可扩展单测 | 负数跳转 |
| 分支跳转 | BGEZAL | all_instr_smoke / 可扩展单测 | $31=PC+8 |
| 分支跳转 | BLTZAL | all_instr_smoke / 可扩展单测 | $31=PC+8 |
| 分支跳转 | J | all_instr_smoke / 可扩展单测 | 直接跳转 |
| 分支跳转 | JAL | branch_jump_link | $31=PC+8 |
| 分支跳转 | JR | branch_jump_link | 寄存器跳转 |
| 分支跳转 | JALR | all_instr_smoke / 可扩展单测 | rd=PC+8 |
| 数据移动 | MFHI | hilo_mult_div | 读 HI |
| 数据移动 | MFLO | hilo_mult_div | 读 LO |
| 数据移动 | MTHI | hilo_mult_div | 写 HI |
| 数据移动 | MTLO | hilo_mult_div | 写 LO |
| 自陷 | BREAK | all_instr_smoke / 建议单测 | Breakpoint 例外 |
| 自陷 | SYSCALL | all_instr_smoke / 建议单测 | SystemCall 例外 |
| 访存 | LB | load_store | 字节符号扩展 |
| 访存 | LBU | load_store | 字节零扩展 |
| 访存 | LH | load_store | 半字符号扩展、对齐检查 |
| 访存 | LHU | load_store | 半字零扩展、对齐检查 |
| 访存 | LW | load_store | load-use stall |
| 访存 | SB | load_store | 小端字节写 |
| 访存 | SH | load_store | 小端半字写 |
| 访存 | SW | load_store | 字写 |
| 特权 | ERET | exception_cp0 | 返回 EPC，清 EXL |
| 特权 | MFC0 | exception_cp0 | 读 EPC/Cause |
| 特权 | MTC0 | exception_cp0 | 写 EPC/Status |
