public class Book
{
    public String title;
    public String pdate;
    public int words;

    public Book(String title, String pdate, int words) {
        this.title = title;
        this.pdate = pdate;
        this.words = words;
    }

    public double price()
    {
        String[] dateParts = pdate.split("-");
        int year = Integer.parseInt(dateParts[0]);
        int month = Integer.parseInt(dateParts[1]);
        double coefficient = (month <= 6) ? 1.2 : 1.18;
        return (words / 1000.0) * 35 * coefficient;
    }

}