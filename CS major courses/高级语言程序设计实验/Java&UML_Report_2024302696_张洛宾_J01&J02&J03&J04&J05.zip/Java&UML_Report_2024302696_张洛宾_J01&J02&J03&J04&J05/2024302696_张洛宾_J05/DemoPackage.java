import MainPackage.SubClass;

public class DemoPackage {
    public static void main(String[] args) {
        SubClass sub = new SubClass("这是父类变量的值");
    }
}