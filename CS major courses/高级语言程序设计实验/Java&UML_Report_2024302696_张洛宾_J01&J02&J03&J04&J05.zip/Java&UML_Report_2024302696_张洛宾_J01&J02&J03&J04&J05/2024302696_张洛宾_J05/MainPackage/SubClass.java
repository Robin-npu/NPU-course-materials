package MainPackage;

public class SubClass extends ParentClass
{
    public SubClass(String value)
    {
        super(value); // 调用父类构造函数完成赋值
        System.out.println("子类赋值完成: " + parentVar);
    }
}