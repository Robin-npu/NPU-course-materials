package MainPackage;

public class ParentClass
{
    protected String parentVar;
    public ParentClass(String value) {
        this.parentVar = value;
        System.out.println("父类构造函数输出: " + parentVar);
    }
}