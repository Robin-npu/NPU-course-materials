//package exp5;
//
//abstract class Speaker {
//    public abstract void speak();
//}
//
//abstract class Runner {
//    public abstract void run();
//}
//
//class Dog extends Speaker {
//    public void speak() {
//        System.out.println("狗的声音:汪、汪！");
//    }
//    private Runner runner = new Runner() {
//        public void run() {
//            System.out.println("狗用四肢跑步");
//        }
//    };
//
//    public void run() {
//        runner.run();
//    }
//}
//
//class Person extends Speaker {
//    public void speak() {
//        System.out.println("人们见面时经常说:您好！");
//    }
//
//    private Runner runner = new Runner() {
//        public void run() {
//            System.out.println("人用两腿跑步");
//        }
//    };
//
//    public void run() {
//        runner.run();
//    }
//}
//
//class Bird extends Speaker {
//    public void speak() {
//        System.out.println("鸟的声音:布谷");
//    }
//
//    private Runner runner = new Runner() {
//        public void run() {
//            System.out.println("鸟用翅膀飞");
//        }
//    };
//
//    public void run() {
//        runner.run();
//    }
//}
//
//public class TestAbstractClass_abstract {
//    public static void main(String[] args) {
//        Dog d = new Dog();
//        d.speak(); d.run();
//        Person p = new Person();
//        p.speak(); p.run();
//        Bird b = new Bird();
//        b.speak(); b.run();
//    }
//}
