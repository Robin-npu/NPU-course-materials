package exp5;
interface Vehicle
{
    void start(String name);
    void stop(String name);
}

class Bike implements Vehicle
{
    public void start(String name) {
        System.out.println(name + "自行车开始");
    }
    public void stop(String name) {
        System.out.println(name + "自行车停止");
    }
}

class Bus implements Vehicle
{
    public void start(String name) {
        System.out.println(name + "公交车开始");
    }
    public void stop(String name) {
        System.out.println(name + "公交车到站");
    }
}

public class InterfaceTest
{
    public static void main(String[] args)
    {
        Bike bike = new Bike();
        Bus bus = new Bus();

        bike.start("test");
        bike.stop("test");

        bus.start("207路");
        bus.stop("207路");
    }
}
