import java.util.*;

class Course
{
    String name;
    double credit;
    double score;
    public Course(String name, double credit, double score)
    {
        this.name = name;
        this.credit = credit;
        this.score = score;
    }
}
class Student
{
    String name;
    List<Course> courses;
    public Student(String name)
    {
        this.name = name;
        this.courses = new ArrayList<>();
    }
    public void addCourse(Course course)
    {
        courses.add(course);
    }
    public double calculateGPA()
    {
        double totalCredits = 0;
        double totalGradePoints = 0;

        for (Course course : courses) {
            double gradePoint = getGradePoint(course.score);
            totalGradePoints += gradePoint * course.credit;
            totalCredits += course.credit;
        }
        double GPA = totalGradePoints / totalCredits;

        return GPA;
    }
    private double getGradePoint(double score)
    {
        if (score >= 85) return 4;
        else if (score >= 75) return 3;
        else if (score >= 60) return 2;
        else if (score >= 45) return 1;
        else return 0;
    }
}
public class GPA
{
    public static void main(String[] args)
    {
        Student zhangYi = new Student("张一");
        zhangYi.addCourse(new Course("数学", 4, 71.5));
        zhangYi.addCourse(new Course("英语", 3.5, 80.4));
        zhangYi.addCourse(new Course("数据结构", 3, 95.5));

        Student liEr = new Student("李二");
        liEr.addCourse(new Course("数学", 4, 78.5));
        liEr.addCourse(new Course("数据结构", 3, 54.5));
        liEr.addCourse(new Course("数据库", 3, 60.5));

        Student zhaoSan = new Student("赵三");
        zhaoSan.addCourse(new Course("数学", 4, 78.5));
        zhaoSan.addCourse(new Course("英语", 3.5, 92.5));
        zhaoSan.addCourse(new Course("数据结构", 3, 71.5));

        // 计算并输出 GPA
        System.out.printf("张一的 GPA: %.2f\n", zhangYi.calculateGPA());
        System.out.printf("李二的 GPA: %.2f\n", liEr.calculateGPA());
        System.out.printf("赵三的 GPA: %.2f\n", zhaoSan.calculateGPA());
    }
}